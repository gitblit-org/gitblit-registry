Team-Branch ACL Hook
====================


